from flask import Flask, render_template, url_for, request, redirect, session, flash, jsonify
import mysql.connector
from mysql.connector import Error
from werkzeug.utils import secure_filename
import os
import docx
import tempfile
import json
import uuid
import re
from datetime import datetime
import requests


app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(12)
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'doc', 'docx'}
app.config['ALLOWED_EXTENSIONS'] = {'pdf', 'png', 'jpg', 'jpeg', 'doc', 'docx'}


DEEPSEEK_API_KEY = "sk-263a8f031c554cfb80ea66624a8a9588"
DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"


# MySQL database configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DB'] = 'ai_learning_assistant'


def create_db_connection():
    try:
        connection = mysql.connector.connect(
            host=app.config['MYSQL_HOST'],
            user=app.config['MYSQL_USER'],
            password=app.config['MYSQL_PASSWORD'],
            database=app.config['MYSQL_DB']
        )
        return connection
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None


def get_db():
    return create_db_connection()


def init_db():
    try:
        # First connect without specifying database to create it if needed
        connection = mysql.connector.connect(
            host=app.config['MYSQL_HOST'], 
            user=app.config['MYSQL_USER'], 
            password=app.config['MYSQL_PASSWORD']
        )
        cursor = connection.cursor()
        
        # Create database if it doesn't exist
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {app.config['MYSQL_DB']}")
        cursor.close()
        connection.close()
        
        # Now connect to the database
        connection = create_db_connection()
        cursor = connection.cursor()
        
        # Create tables
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(100) NOT NULL,
            points INT DEFAULT 0,
            current_streak INT DEFAULT 0,
            max_streak INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """)
        
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS uploaded_files (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            filename VARCHAR(255) NOT NULL,
            filepath VARCHAR(255) NOT NULL,
            upload_date TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )
        """)
        
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS questions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            question_text TEXT NOT NULL,
            source_file VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )
        """)
        
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS practices (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            question_id INT NOT NULL,
            user_answer TEXT,
            is_correct BOOLEAN,
            date TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
            FOREIGN KEY (question_id) REFERENCES questions (id) ON DELETE CASCADE
        )
        """)
        
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS mistakes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            question_id INT NOT NULL,
            user_answer TEXT,
            subject VARCHAR(50),
            date TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
            FOREIGN KEY (question_id) REFERENCES questions (id) ON DELETE CASCADE
        )
        """)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS temp_parsed_data (
            id INT AUTO_INCREMENT PRIMARY KEY,
            session_id VARCHAR(255) NOT NULL,
            questions TEXT,
            extracted_content TEXT,
            filename VARCHAR(255),
            reading_passage TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (session_id)
        )
        """)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS exercises (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )
        """)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS exercise_questions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            exercise_id INT NOT NULL,
            question_type ENUM('MCQ', 'SPR', 'TEXT', 'FIGURE') NOT NULL,
            question_text TEXT,
            options JSON,
            correct_answer VARCHAR(10),
            expected_answer TEXT,
            content TEXT,
            figure_path VARCHAR(255),
            caption VARCHAR(255),
            question_order INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (exercise_id) REFERENCES exercises (id) ON DELETE CASCADE
        )
        """)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS student_exercises (
            id INT AUTO_INCREMENT PRIMARY KEY,
            student_id INT NOT NULL,
            exercise_id INT NOT NULL,
            correct_answers INT NULL,
            total_questions INT NULL,
            answers JSON NULL,
            completed_at TIMESTAMP,
            ai_analysis TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES users (id) ON DELETE CASCADE,
            FOREIGN KEY (exercise_id) REFERENCES exercises (id) ON DELETE CASCADE
        )
        """)
        
        # Check if test user exists
        cursor.execute("SELECT * FROM users WHERE username = 'test'")
        if not cursor.fetchone():
            cursor.execute(
                "INSERT INTO users (username, password) VALUES (%s, %s)",
                ('test', 'test')
            )
        
        connection.commit()
        cursor.close()
        connection.close()


    except Error as e:
        print(f"Error initializing database: {e}")


@app.route('/login')
def login():
    return render_template('login.html')


@app.route('/checklogin', methods=["POST"])
def checklogin():
    username = request.form.get('username')
    password = request.form.get('password')


    connection = create_db_connection()


    if connection:
        try:
            cursor = connection.cursor(dictionary=True)
            cursor.execute("SELECT * FROM users WHERE username=%s AND password=%s", (username, password))
            user = cursor.fetchone()
            print(user)
            if user:
                print('entered user judgment')
                session['logged_in'] = True
                session['username'] = user['username']
                session['password'] = user['password']
                session['current_streak'] = user['current_streak']
                session['points'] = user['points']
                flash('Login successful!', 'success')
                next_page = request.args.get('next')
                return redirect(next_page or url_for('index'))
            else:
                flash('Incorrect username or password!', 'danger')
            cursor.close()
            connection.close()


        except Error as e:
            print(f"Error during login: {e}")
            flash('Database error, please try again later', 'danger')


    return redirect(url_for('index'))


@app.route('/')
def index():
    if not session.get('logged_in'):
        return redirect(url_for('login'))


    return redirect(url_for('exercise'))


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# After extracting Word document content, you can add this parsing logic
def parse_questions_from_text(text):
    questions = []
    lines = text.split('\n')
    
    current_question = None
    options = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Detect question lines (simple heuristic)
        if line.startswith(('Q:', 'Question:', 'Question：')) or (len(line) > 10 and '?' in line):
            if current_question:
                questions.append({
                    'question': current_question,
                    'options': options
                })
            
            current_question = line
            options = []
        
        # Detect options (starting with A, B, C, etc.)
        elif any(line.startswith(f'{letter}.') or line.startswith(f'{letter})') for letter in OPTION_LETTERS):
            options.append(line)
    
    # Add the last question
    if current_question:
        questions.append({
            'question': current_question,
            'options': options
        })
    
    return questions


def parse_word_document(doc):
    """
    Parse reading materials and multiple choice questions from Word documents
    """
    questions = []
    reading_passage = ""
    current_question = None
    current_options = []
    question_number = 0
    in_reading_passage = True
    
    # Extract all text
    full_text = []
    for paragraph in doc.paragraphs:
        text = paragraph.text.strip()
        if text:
            full_text.append(text)
    
    # Analyze text structure
    for i, text in enumerate(full_text):
        # Detect question start (number followed by dot or parenthesis)
        question_match = re.match(r'^(\d+)[\.\)]\s*(.+)$', text)
        
        if question_match:
            in_reading_passage = False
            
            # Save previous question
            if current_question:
                questions.append({
                    'type': 'MCQ',
                    'number': question_number,
                    'question': current_question,
                    'options': current_options,
                    'correctAnswer': 0
                })
            
            # Start new question
            question_number = int(question_match.group(1))
            current_question = question_match.group(2).strip()
            current_options = []
        
        # Detect options (starting with A-D)
        elif not in_reading_passage and re.match(r'^[A-D][\.\)]\s*.+$', text):
            option_match = re.match(r'^[A-D][\.\)]\s*(.+)$', text)
            if option_match:
                current_options.append(option_match.group(1).strip())
        
        # If in reading passage section
        elif in_reading_passage:
            # Skip file information markers
            if not re.match(r'^\[file (name|content)', text):
                reading_passage += text + "\n\n"
    
    # Add the last question
    if current_question:
        questions.append({
            'type': 'MCQ',
            'number': question_number,
            'question': current_question,
            'options': current_options,
            'correctAnswer': 0
        })
    
    # If no questions parsed but document has content, create reading material
    if not questions and reading_passage:
        # Make reading material a short answer question
        questions.append({
            'type': 'SPR',
            'number': 1,
            'question': reading_passage[:500] + "..." if len(reading_passage) > 500 else reading_passage,
            'expectedAnswer': ""
        })
    
    return questions, reading_passage


@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        flash('Please select a file', 'error')
        return redirect(url_for('importing'))
    
    file = request.files['file']
    
    if file.filename == '':
        flash('Please select a file', 'error')
        return redirect(url_for('importing'))
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        
        # Create temporary directory to save file
        temp_dir = tempfile.mkdtemp()
        file_path = os.path.join(temp_dir, filename)
        file.save(file_path)
        
        try:
            questions = []
            reading_passage = ""
            extracted_content = ""
            
            # Process Word documents
            if filename.lower().endswith(('.doc', '.docx')):
                doc = docx.Document(file_path)
                
                # Extract all text content
                full_text = []
                for paragraph in doc.paragraphs:
                    if paragraph.text.strip():
                        full_text.append(paragraph.text)
                extracted_content = "\n".join(full_text)
                
                # Parse questions and reading material
                questions, reading_passage = parse_word_document(doc)
                
                # If no questions parsed, use entire content
                if not questions and extracted_content:
                    questions = [{
                        'type': 'SPR',
                        'number': 1,
                        'question': extracted_content,
                        'expectedAnswer': ""
                    }]
            
            # Generate unique session ID
            session_id = str(uuid.uuid4())
            
            # Store in database
            connection = create_db_connection()
            if connection:
                cursor = connection.cursor()
                cursor.execute(
                    "INSERT INTO temp_parsed_data (session_id, questions, extracted_content, filename, reading_passage) VALUES (%s, %s, %s, %s, %s)",
                    (session_id, json.dumps(questions), extracted_content, filename, reading_passage)
                )
                connection.commit()
                cursor.close()
                connection.close()
            
            # Only store reference ID in session
            session['parsed_data_id'] = session_id
            
            # Redirect to edit page
            return redirect(url_for('edit'))
            
        except Exception as e:
            flash(f'Error processing file: {str(e)}', 'error')
            return redirect(url_for('importing'))
        finally:
            # Clean up temporary files
            import shutil
            shutil.rmtree(temp_dir)
    
    else:
        flash('Unsupported file type', 'error')
        return redirect(url_for('importing'))


@app.route('/edit')
def edit():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    questions = []
    extracted_content = ""
    filename = ""
    reading_passage = ""
    
    # Get parsed data from database
    session_id = session.get('parsed_data_id')
    if session_id:
        connection = create_db_connection()
        if connection:
            cursor = connection.cursor(dictionary=True)
            cursor.execute(
                "SELECT questions, extracted_content, filename, reading_passage FROM temp_parsed_data WHERE session_id = %s",
                (session_id,)
            )
            data = cursor.fetchone()
            if data:
                questions = json.loads(data['questions']) if data['questions'] else []
                extracted_content = data['extracted_content'] or ""
                filename = data['filename'] or ""
                reading_passage = data['reading_passage'] or ""
            
            cursor.close()
            connection.close()
            
            # Clean up reference in session
            session.pop('parsed_data_id', None)
    
    return render_template('edit.html', 
                          username=session['username'],
                          questions=questions,
                          extracted_content=extracted_content,
                          filename=filename,
                          reading_passage=reading_passage)


@app.route('/submitEditedExercise', methods=['POST'])
def submitEditedExercise():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    try:
        # Get form data
        data = request.get_json()
        title = data.get('title')
        questions = data.get('questions', [])
        textareas = data.get('textareas', [])
        figures = data.get('figures', [])
        
        # Get current user ID
        connection = create_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT id FROM users WHERE username = %s", (session['username'],))
        user = cursor.fetchone()
        user_id = user['id']
        
        # Insert exercise record
        cursor.execute(
            "INSERT INTO exercises (user_id, title) VALUES (%s, %s)",
            (user_id, title)
        )
        exercise_id = cursor.lastrowid
        
        # Insert question records
        order_counter = 0
        
        # Insert text areas
        for textarea in textareas:
            if textarea.get('content'):
                cursor.execute(
                    """INSERT INTO exercise_questions 
                    (exercise_id, question_type, content, question_order) 
                    VALUES (%s, 'TEXT', %s, %s)""",
                    (exercise_id, textarea['content'], order_counter)
                )
                order_counter += 1
        
        # Insert questions
        for question in questions:
            if question['type'] == 'MCQ':
                cursor.execute(
                    """INSERT INTO exercise_questions 
                    (exercise_id, question_type, question_text, options, correct_answer, question_order) 
                    VALUES (%s, 'MCQ', %s, %s, %s, %s)""",
                    (exercise_id, question['question'], json.dumps(question['options']), 
                     question['correctAnswer'], order_counter)
                )
            elif question['type'] == 'SPR':
                cursor.execute(
                    """INSERT INTO exercise_questions 
                    (exercise_id, question_type, question_text, expected_answer, question_order) 
                    VALUES (%s, 'SPR', %s, %s, %s)""",
                    (exercise_id, question['question'], question['expectedAnswer'], order_counter)
                )
            order_counter += 1
        
        # Insert images (simplified handling)
        for figure in figures:
            cursor.execute(
                """INSERT INTO exercise_questions 
                (exercise_id, question_type, caption, question_order) 
                VALUES (%s, 'FIGURE', %s, %s)""",
                (exercise_id, figure.get('caption', ''), order_counter)
            )
            order_counter += 1
        
        connection.commit()
        cursor.close()
        connection.close()
        
        return jsonify({'success': True, 'exercise_id': exercise_id, 'message': 'Exercise saved successfully'})
        
    except Exception as e:
        print(f"Error saving exercise: {e}")
        return jsonify({'success': False, 'message': 'Error saving exercise'})


@app.route('/myEditedExercise')
def myEditedExercise():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    try:
        # Get current user ID
        connection = create_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT id FROM users WHERE username = %s", (session['username'],))
        user = cursor.fetchone()
        user_id = user['id']
        
        # Get all exercises created by user
        cursor.execute("""
            SELECT e.id, e.title, e.created_at, e.updated_at, 
                   COUNT(eq.id) as question_count
            FROM exercises e 
            LEFT JOIN exercise_questions eq ON e.id = eq.exercise_id 
            WHERE e.user_id = %s 
            GROUP BY e.id 
            ORDER BY e.created_at DESC
        """, (user_id,))
        exercises = cursor.fetchall()
        
        cursor.close()
        connection.close()
        
        return render_template('my_exercises.html', 
                              username=session['username'],
                              exercises=exercises)
        
    except Exception as e:
        print(f"Error fetching exercises: {e}")
        flash('Error fetching exercise list', 'error')
        return redirect(url_for('index'))


@app.route('/exercise/<int:exercise_id>')
def view_exercise(exercise_id):
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    try:
        connection = create_db_connection()
        cursor = connection.cursor(dictionary=True)
        
        # Get basic exercise information
        cursor.execute("""
            SELECT e.*, u.username 
            FROM exercises e 
            JOIN users u ON e.user_id = u.id 
            WHERE e.id = %s
        """, (exercise_id,))
        exercise = cursor.fetchone()
        
        if not exercise:
            flash('Exercise does not exist', 'error')
            return redirect(url_for('exercise'))
        
        # Get all questions for this exercise
        cursor.execute("""
            SELECT * FROM exercise_questions 
            WHERE exercise_id = %s 
            ORDER BY question_order
        """, (exercise_id,))
        questions = cursor.fetchall()
        
        # Parse JSON options
        for question in questions:
            if question['options']:
                try:
                    question['options'] = json.loads(question['options'])
                except json.JSONDecodeError:
                    question['options'] = []
                    print(f"Error decoding JSON for question {question['id']}")
        
        cursor.close()
        connection.close()
        
        return render_template('view_exercise.html',
                              username=session['username'],
                              exercise=exercise,
                              questions=questions,
                              now=datetime.now())
        
    except Exception as e:
        print(f"Error fetching exercise: {e}")
        flash('Error fetching exercise', 'error')
        return redirect(url_for('exercise'))


@app.route('/search_exercise', methods=['GET'])
def search_exercise():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    
    exercise_id = request.args.get('exerciseSearch')
    
    if not exercise_id:
        flash('Please enter an exercise ID', 'error')
        return redirect(url_for('exercise'))
    
    try:
        exercise_id = int(exercise_id)
        
        # Check if exercise exists
        connection = create_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT id FROM exercises WHERE id = %s", (exercise_id,))
        exercise = cursor.fetchone()
        
        if not exercise:
            flash('Exercise does not exist', 'error')
            return redirect(url_for('exercise'))
        
        # Add exercise to student's list
        cursor.execute("SELECT id FROM users WHERE username = %s", (session['username'],))
        user = cursor.fetchone()
        user_id = user['id']
        
        # Check if already added
        cursor.execute("""
            SELECT id FROM student_exercises 
            WHERE student_id = %s AND exercise_id = %s
        """, (user_id, exercise_id))
        
        if not cursor.fetchone():
            # Add to student's exercise list
            cursor.execute("""
                INSERT INTO student_exercises (student_id, exercise_id) 
                VALUES (%s, %s)
            """, (user_id, exercise_id))
            connection.commit()
            flash('Exercise added to your list', 'success')
        else:
            flash('Exercise is already in your list', 'info')
        
        cursor.close()
        connection.close()
        
        return redirect(url_for('view_exercise', exercise_id=exercise_id))
        
    except ValueError:
        flash('Please enter a valid exercise ID', 'error')
        return redirect(url_for('exercise'))
    except Exception as e:
        print(f"Error searching exercise: {e}")
        flash('Error searching for exercise', 'error')
        return redirect(url_for('exercise'))


@app.route('/exercise')
def exercise():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('exercise.html')


@app.route('/exerciseFinished', methods=["POST"])
def exercise_finished():
    """Receive submitted answers and redirect to results page"""
    if not session.get('logged_in'):
        return redirect(url_for('login'))


    # 1. Get submitted parameters
    answers_json = request.form.get('answers')
    exercise_id = request.form.get('exercise_id')


    # 2. Validate parameters
    if not answers_json or not exercise_id:
        return "Missing required parameters (answers or exercise ID)", 400
    try:
        answers = json.loads(answers_json)  # Parse user answers: [{question_id, answer}, ...]
        exercise_id = int(exercise_id)
    except (json.JSONDecodeError, ValueError):
        return "Invalid parameter format (answers must be JSON, exercise ID must be a number)", 400


    # 3. Store answers in session
    session['submitted_answers'] = answers
    session['current_exercise_id'] = exercise_id


    # 4. Redirect to results
    return redirect(url_for('exercise_result'))


@app.route('/exercise_result')
def exercise_result():
    """Generate exercise results page showing correct/incorrect for each question"""
    if not session.get('logged_in'):
        return redirect(url_for('login'))


    # 1. Get submitted answers and exercise ID from session
    submitted_answers = session.get('submitted_answers')
    exercise_id = session.get('current_exercise_id')


    # 2. Validate data integrity
    if not submitted_answers or not exercise_id:
        flash('No submitted exercise data found, please complete the exercise again', 'error')
        return redirect(url_for('exercise'))


    # 3. Connect to database
    connection = create_db_connection()
    if not connection:
        flash('Database connection failed, please try again later', 'error')
        return redirect(url_for('exercise'))


    try:
        cursor = connection.cursor(dictionary=True)
        # Get basic exercise information
        cursor.execute("""
            SELECT e.*, u.username 
            FROM exercises e 
            JOIN users u ON e.user_id = u.id 
            WHERE e.id = %s
        """, (exercise_id,))
        exercise = cursor.fetchone()
        if not exercise:
            flash('Exercise does not exist', 'error')
            return redirect(url_for('exercise'))


        # Get all multiple choice questions for this exercise
        cursor.execute("""
            SELECT id, question_text, options, correct_answer 
            FROM exercise_questions 
            WHERE exercise_id = %s AND question_type = 'MCQ'
            ORDER BY question_order
        """, (exercise_id,))
        db_questions = cursor.fetchall()
        total_question = len(db_questions)
        if total_question == 0:
            flash('This exercise has no multiple choice questions', 'error')
            return redirect(url_for('view_exercise', exercise_id=exercise_id))


        # Parse options
        for q in db_questions:
            if q['options']:
                try:
                    q['options'] = json.loads(q['options'])
                except json.JSONDecodeError:
                    q['options'] = []


        # Compare answers
        question_results = []
        total_correct = 0
        OPTION_LETTERS = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"]
        
        for db_q in db_questions:
            # Get user answer (letter format, e.g. "A")
            user_ans = next(
                (ans['answer'] for ans in submitted_answers if str(ans['question_id']) == str(db_q['id'])),
                None
            )
            
            # Convert correct answer index from database to letter (e.g. 0 -> "A")
            correct_index = int(db_q['correct_answer']) if db_q['correct_answer'] else 0
            correct_letter = OPTION_LETTERS[correct_index] if correct_index < len(OPTION_LETTERS) else ""
            
            # Compare user answer and correct answer (both in letter format)
            is_correct = user_ans == correct_letter
            if is_correct:
                total_correct += 1
                
            question_results.append({
                'question_id': db_q['id'],
                'question_text': db_q['question_text'],
                'options': db_q['options'],
                'user_answer': user_ans,
                'correct_answer': correct_letter,  # Store correct answer in letter format
                'is_correct': is_correct
            })


        # Calculate score rate
        score_rate = round((total_correct / total_question) * 100, 1) if total_question > 0 else 0
        completed_at = datetime.now()


        # Get current user ID
        cursor.execute("SELECT id FROM users WHERE username = %s", (session['username'],))
        student_id = cursor.fetchone()['id']


        # Check and update student exercise record
        cursor.execute("""
            SELECT id FROM student_exercises 
            WHERE student_id = %s AND exercise_id = %s
        """, (student_id, exercise_id))
        student_exercise = cursor.fetchone()
        
        # Prepare answer record for storage
        answers_to_store = json.dumps(submitted_answers)
        
        if student_exercise:
            # Update record with correct count, total questions, and complete answer record
            cursor.execute("""
                UPDATE student_exercises 
                SET correct_answers = %s, 
                    total_questions = %s,
                    answers = %s,
                    completed_at = %s 
                WHERE id = %s
            """, (total_correct, total_question, answers_to_store, completed_at, student_exercise['id']))
        else:
            # Insert new record
            cursor.execute("""
                INSERT INTO student_exercises 
                (student_id, exercise_id, correct_answers, total_questions, answers, completed_at) 
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (student_id, exercise_id, total_correct, total_question, answers_to_store, completed_at))
        
        connection.commit()


        # Render results page
        return render_template(
            'exercise_result.html',
            exercise=exercise,
            question_results=question_results,
            total_question=total_question,
            total_correct=total_correct,
            score_rate=score_rate,
            completed_at=completed_at,
            now=datetime.now(),
            username=session['username']
        )


    except Error as e:
        print(f"Database error: {str(e)}")
        flash(f'Database error: {str(e)}', 'error')
        return redirect(url_for('view_exercise', exercise_id=exercise_id))
    except Exception as e:
        print(f"Failed to generate results: {str(e)}")
        flash(f'Server error: {str(e)}', 'error')
        return redirect(url_for('view_exercise', exercise_id=exercise_id))


@app.route('/aiGeneratingResult/<int:exercise_id>', methods=['POST'])
def aiGeneratingResult(exercise_id):
    if not session.get('logged_in'):
        return jsonify({'success': False, 'message': 'Please log in first'})
    
    try:
        # Get student's submitted answer data
        student_id = get_user_id(session['username'])
        connection = create_db_connection()
        cursor = connection.cursor(dictionary=True)
        
        # Get student exercise record
        cursor.execute("""
            SELECT se.*, e.title 
            FROM student_exercises se
            JOIN exercises e ON se.exercise_id = e.id
            WHERE se.student_id = %s AND se.exercise_id = %s
        """, (student_id, exercise_id))
        student_exercise = cursor.fetchone()
        
        if not student_exercise:
            return jsonify({'success': False, 'message': 'No exercise record found'})
        
        # Get questions and correct answers
        cursor.execute("""
            SELECT eq.id, eq.question_text, eq.options, eq.correct_answer, eq.question_type
            FROM exercise_questions eq
            WHERE eq.exercise_id = %s
        """, (exercise_id,))
        questions = cursor.fetchall()
        
        # Parse data
        answers = json.loads(student_exercise['answers']) if student_exercise['answers'] else []
        total_questions = student_exercise['total_questions']
        correct_answers = student_exercise['correct_answers']
        
        # Prepare data to send to DeepSeek API
        prompt = f"""
        Please analyze the student's exercise results and generate a detailed report.
        
        Exercise name: {student_exercise['title']}
        Completion status: {correct_answers}/{total_questions} correct, score {round((correct_answers/total_questions)*100, 1)}%
        
        Questions and answers:
        """
        
        # Build question details
        question_details = []
        for question in questions:
            # Find student's answer
            user_answer = next((a for a in answers if str(a['question_id']) == str(question['id'])), None)
            
            # Parse options
            options = json.loads(question['options']) if question['options'] else []
            
            # Correct answer letter
            correct_letter = ""
            if question['question_type'] == 'MCQ' and question['correct_answer']:
                correct_index = int(question['correct_answer'])
                correct_letter = ["A", "B", "C", "D"][correct_index] if correct_index < 4 else ""
            
            question_detail = f"Question: {question['question_text']}\n"
            if options:
                question_detail += f"Options: {', '.join([f'{chr(65+i)}.{opt}' for i, opt in enumerate(options)])}\n"
            question_detail += f"Correct answer: {correct_letter}\n"
            if user_answer:
                question_detail += f"Student's answer: {user_answer['answer']}\n"
                is_correct = user_answer['answer'] == correct_letter
                question_detail += f"Correct: {'Yes' if is_correct else 'No'}\n"
            
            question_details.append(question_detail)
        
        prompt += "\n".join(question_details)
        prompt += "\nPlease generate an analysis report including: 1. Overall evaluation 2. Error analysis 3. Improvement suggestions 4. Knowledge point summary"
        
        # Call DeepSeek API
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}"
        }
        
        data = {
            "model": "deepseek-chat",
            "messages": [
                {"role": "system", "content": "You are an educational assessment expert, skilled at analyzing students' answers and providing targeted suggestions."},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.7
        }
        
        response = requests.post(DEEPSEEK_API_URL, headers=headers, json=data)
        response_data = response.json()
        
        if response.status_code != 200 or not response_data.get('choices'):
            return jsonify({
                'success': False, 
                'message': f'API call failed: {response_data.get("error", {}).get("message", "Unknown error")}'
            })
        
        # Get AI-generated report
        ai_report = response_data['choices'][0]['message']['content']
        
        # Print report (console output)
        print("\n===== AI-generated Exercise Report =====")
        print(ai_report)
        print("======================================\n")
        
        # Store report in database
        cursor.execute("""
            UPDATE student_exercises
            SET ai_analysis = %s
            WHERE id = %s
        """, (ai_report, student_exercise['id']))
        connection.commit()
        
        cursor.close()
        connection.close()
        
        return jsonify({
            'success': True, 
            'message': 'AI report generated successfully',
            'report': ai_report
        })
        
    except Exception as e:
        print(f"Error generating AI report: {e}")
        return jsonify({'success': False, 'message': f'Error generating report: {str(e)}'})


def get_user_id(username):
    connection = create_db_connection()
    if connection:
        try:
            cursor = connection.cursor(dictionary=True)
            cursor.execute("SELECT id FROM users WHERE username = %s", (username,))
            user = cursor.fetchone()
            cursor.close()
            connection.close()
            return user['id'] if user else None
        except Error as e:
            print(f"Error getting user ID: {e}")
            return None
    return None


# Define OPTION_LETTERS which was missing in original code
OPTION_LETTERS = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"]


if __name__ == '__main__':
    init_db()
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    app.run(host="0.0.0.0", port="80")
